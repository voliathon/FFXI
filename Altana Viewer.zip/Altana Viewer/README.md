# AltanaView
The Updated 2020 AltanaView. Original Program not written by me. 

Dats recent as of 5/8/2020. 

Please report any incorrect or missing dats, I will fix it.

## Please delete your old versions of altana viewer as the file naming conventions have drastically changed.

To-Do List:
* Clean up Actions
* Add Newest Spell Tiers
* Fix some Naming problems across Items.
* Rewrite the entire AltanaView
